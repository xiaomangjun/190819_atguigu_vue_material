import Vue from 'vue'
import App from './App'

new Vue({
  components: { 
    App: App
  },
  template: '<App/>',
}).$mount('#root')