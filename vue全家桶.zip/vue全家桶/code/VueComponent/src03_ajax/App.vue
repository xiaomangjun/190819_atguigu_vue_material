<template>
  <div class="container">
    <Search/>
    <Main/>
  </div>
</template>

<script type="text/ecmascript-6">
  import Search from './components/Search'
  import Main from './components/Main'
  export default {
    components: {
      Main,
      Search
    }
  }
</script>

<style scoped>

 
</style>
