<template>
  <ul>
    <li>new001</li>
    <li>new003</li>
    <li>new005</li>
  </ul>
</template>

<script type="text/ecmascript-6">
  export default {
  }
</script>

<style scoped>

 
</style>
