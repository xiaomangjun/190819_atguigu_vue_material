/* 
包含n个mutation函数名常量模块
*/
export const REQUESTING = 'requesting'
export const REQ_SUCCESS = 'req_success'
export const REQ_ERROR = 'req_error'