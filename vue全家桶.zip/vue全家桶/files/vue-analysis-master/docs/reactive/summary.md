# 原理图

<img :src="$withBase('/assets/reactive.png')">
